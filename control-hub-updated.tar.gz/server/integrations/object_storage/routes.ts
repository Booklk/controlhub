import type { Express } from "express";
import { ObjectStorageService, ObjectNotFoundError } from "./objectStorage";
import { logger } from "../../security-middleware";

/**
 * Register object storage routes for file uploads.
 *
 * This provides example routes for the presigned URL upload flow:
 * 1. POST /api/uploads/request-url - Get a presigned URL for uploading
 * 2. The client then uploads directly to the presigned URL
 *
 * IMPORTANT: These are example routes. Customize based on your use case:
 * - Add authentication middleware for protected uploads
 * - Add file metadata storage (save to database after upload)
 * - Add ACL policies for access control
 */
type AuthMiddleware = (req: any, res: any, next: any) => void;

export function registerObjectStorageRoutes(app: Express, auth?: AuthMiddleware): void {
  const objectStorageService = new ObjectStorageService();
  const authGuard: AuthMiddleware = auth ?? ((req: any, res: any, next: any) => next());

  /**
   * Request a presigned URL for file upload.
   *
   * Request body (JSON):
   * {
   *   "name": "filename.jpg",
   *   "size": 12345,
   *   "contentType": "image/jpeg"
   * }
   *
   * Response:
   * {
   *   "uploadURL": "https://storage.googleapis.com/...",
   *   "objectPath": "/objects/uploads/uuid"
   * }
   *
   * IMPORTANT: The client should NOT send the file to this endpoint.
   * Send JSON metadata only, then upload the file directly to uploadURL.
   */
  app.post("/api/uploads/request-url", authGuard, async (req, res) => {
    try {
      const { name, fileName, size, contentType } = req.body;
      const actualName = name || fileName;

      if (!actualName) {
        return res.status(400).json({
          error: "Missing required field: name or fileName",
        });
      }

      const uploadURL = await objectStorageService.getObjectEntityUploadURL();

      // Extract object path from the presigned URL for later reference
      const objectPath = objectStorageService.normalizeObjectEntityPath(uploadURL);

      res.json({
        uploadURL,
        objectPath,
        // Echo back the metadata for client convenience
        metadata: { name: actualName, size, contentType },
      });
    } catch (error) {
      logger.error("Error generating upload URL:", { error });
      res.status(500).json({ error: "Failed to generate upload URL" });
    }
  });

  /**
   * Serve public files from object storage.
   *
   * GET /api/public/:filename
   *
   * This serves public files uploaded to the 'public' directory.
   */
  app.get("/api/public/:filename", async (req, res) => {
    try {
      const filename = req.params.filename;
      const publicFile = await objectStorageService.searchPublicObject(filename);
      
      if (!publicFile) {
        return res.status(404).json({ error: "File not found" });
      }
      
      res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
      await objectStorageService.downloadObject(publicFile, res, 86400);
    } catch (error) {
      logger.error("Error serving public file:", { error });
      return res.status(500).json({ error: "Failed to serve file" });
    }
  });

  /**
   * Serve uploaded objects.
   *
   * GET /objects/:objectPath(*)
   *
   * This serves files from object storage. For public files, no auth needed.
   * For protected files, add authentication middleware and ACL checks.
   */
  app.get(/^\/objects\/(.*)$/, async (req, res) => {
    try {
      const objectFile = await objectStorageService.getObjectEntityFile(req.path);
      await objectStorageService.downloadObject(objectFile, res);
    } catch (error) {
      logger.error("Error serving object:", { error });
      if (error instanceof ObjectNotFoundError) {
        return res.status(404).json({ error: "Object not found" });
      }
      return res.status(500).json({ error: "Failed to serve object" });
    }
  });
}

